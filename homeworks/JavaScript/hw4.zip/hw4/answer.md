forEach loop is used to iterate all elements of an array. It works like basically for loop. 
By using forEach loop we can modify array elements. The return value of this loop is undefined. 