/*
let div = document.body.firstElementChild;
let ul = div.nextElementSibling;
let li = ul.children[1];
console.log(div);
console.log(li);
console.log(ul);*/

let table = document.body.firstElementChild;
console.log(table);
let tr = table.childNodes;
